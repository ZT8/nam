// Recovered Objective-C method names. Superclasses and source types are not reconstructed.
// Each declaration is preceded by the original runtime type encoding and implementation address.

@interface DLCrashViewController /* superclass unresolved */
// 0x8991c encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLoad;
// 0x8b8a4 encoding: v16@0:8
- (id /* see encoding for actual type */)dismiss;
// 0x8b8b8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)sendCrash:(id)arg1;
// 0x8bdac encoding: v40@0:8@16q24@32
- (id /* see encoding for actual type */)mailComposeController:(id)arg1 didFinishWithResult:(id)arg2 error:(id)arg3;
// 0x8c158 encoding: @16@0:8
- (id /* see encoding for actual type */)infoDict;
// 0x8c168 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setInfoDict:(id)arg1;
// 0x8c17c encoding: @16@0:8
- (id /* see encoding for actual type */)appName;
// 0x8c18c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setAppName:(id)arg1;
// 0x8c1a0 encoding: @16@0:8
- (id /* see encoding for actual type */)appVersion;
// 0x8c1b0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setAppVersion:(id)arg1;
// 0x8c1c4 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLHelper /* superclass unresolved */
// 0x8d0ec encoding: v24@0:8Q16
+ (id /* see encoding for actual type */)HUDWithState:(id)arg1;
// 0x8d8c8 encoding: @24@0:8@16
+ (id /* see encoding for actual type */)getFile:(id)arg1;
// 0x8d984 encoding: v48@0:8@16Q24@32d40
+ (id /* see encoding for actual type */)addLine:(id)arg1 atPosition:(id)arg2 withColor:(id)arg3 lineHeight:(id)arg4;
// 0x8dbec encoding: B16@0:8
+ (id /* see encoding for actual type */)is_iPhoneX;
// 0x8dc4c encoding: @16@0:8
+ (id /* see encoding for actual type */)topWindow;
// 0x8dcd0 encoding: @24@0:8@16
+ (id /* see encoding for actual type */)imageIcon:(id)arg1;
// 0x8ddd0 encoding: @32@0:8@16@24
+ (id /* see encoding for actual type */)image:(id)arg1 color:(id)arg2;
// 0x8def0 encoding: @40@0:8@16{CGSize=dd}24
+ (id /* see encoding for actual type */)resizeImageView:(id)arg1 size:(id)arg2;
// 0x8e080 encoding: v32@0:8@16@24
+ (id /* see encoding for actual type */)showMessageWithTitle:(id)arg1 message:(id)arg2;
// 0x8eb1c encoding: v40@0:8@16@24@32
+ (id /* see encoding for actual type */)showMessageWithTitle:(id)arg1 message:(id)arg2 viewController:(id)arg3;
// 0x8eec8 encoding: v32@0:8@?16@?24
+ (id /* see encoding for actual type */)showConfirmMessageSave:(id)arg1 share:(id)arg2;
// 0x8f6ac encoding: @40@0:8@16^@24^@32
+ (id /* see encoding for actual type */)sendSynchronousRequest:(id)arg1 returningResponse:(id)arg2 error:(id)arg3;
// 0x8faa8 encoding: q24@0:8@16
+ (id /* see encoding for actual type */)DLMediaSize:(id)arg1;
// 0x8fb8c encoding: q24@0:8@16
+ (id /* see encoding for actual type */)getStatusCodeFromURL:(id)arg1;
// 0x8fc64 encoding: v24@0:8@16
+ (id /* see encoding for actual type */)switchToRTL:(id)arg1;
// 0x8fcb8 encoding: B16@0:8
+ (id /* see encoding for actual type */)isDarkMode;
// 0x8fd58 encoding: @48@0:8@16@24@32q40
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 key:(id)arg2 defaultValue:(id)arg3 statusMode:(id)arg4;
// 0x8fef4 encoding: @56@0:8@16@24@32@40q48
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 detail:(id)arg2 image:(id)arg3 url:(id)arg4 statusMode:(id)arg5;
// 0x90010 encoding: v24@0:8@16
+ (id /* see encoding for actual type */)saveMediaIdForStory:(id)arg1;
// 0x902b0 encoding: @24@0:8@16
+ (id /* see encoding for actual type */)findViewController:(id)arg1;
// 0x90388 encoding: @16@0:8
+ (id /* see encoding for actual type */)topMostController;
// 0x90480 encoding: @16@0:8
+ (id /* see encoding for actual type */)keyWindow;
// 0x90600 encoding: v20@0:8i16
+ (id /* see encoding for actual type */)vibration:(id)arg1;
// 0x9064c encoding: B16@0:8
+ (id /* see encoding for actual type */)isDeviceLanguageArabic;
// 0x906d0 encoding: v28@0:8B16@20
+ (id /* see encoding for actual type */)setBool:(id)arg1 forKey:(id)arg2;
// 0x9077c encoding: v32@0:8@16@24
+ (id /* see encoding for actual type */)setObject:(id)arg1 forKey:(id)arg2;
// 0x9083c encoding: B24@0:8@16
+ (id /* see encoding for actual type */)boolForKey:(id)arg1;
@end

@interface DLInsta /* superclass unresolved */
// 0x908b8 encoding: @16@0:8
+ (id /* see encoding for actual type */)sharedInstance;
// 0x90968 encoding: v32@0:8@16@?24
+ (id /* see encoding for actual type */)featcAllInfoByUserPK:(id)arg1 completion:(id)arg2;
// 0x90cd4 encoding: v24@0:8@16
+ (id /* see encoding for actual type */)openUsernameInApp:(id)arg1;
@end

@interface MBProgressHUD /* superclass unresolved */
// 0x91098 encoding: v16@0:8
- (id /* see encoding for actual type */)commonInit;
// 0x91200 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0x91258 encoding: @24@0:8@16
- (id /* see encoding for actual type */)initWithCoder:(id)arg1;
// 0x912b0 encoding: @24@0:8@16
- (id /* see encoding for actual type */)initWithView:(id)arg1;
// 0x913c0 encoding: v16@0:8
- (id /* see encoding for actual type */)dealloc;
// 0x9140c encoding: v20@0:8B16
- (id /* see encoding for actual type */)showAnimated:(id)arg1;
// 0x91640 encoding: v20@0:8B16
- (id /* see encoding for actual type */)hideAnimated:(id)arg1;
// 0x91920 encoding: v28@0:8B16d20
- (id /* see encoding for actual type */)hideAnimated:(id)arg1 afterDelay:(id)arg2;
// 0x91a48 encoding: v24@0:8@16
- (id /* see encoding for actual type */)handleGraceTimer:(id)arg1;
// 0x91aa0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)handleMinShowTimer:(id)arg1;
// 0x91ad8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)handleHideTimer:(id)arg1;
// 0x91b34 encoding: v16@0:8
- (id /* see encoding for actual type */)didMoveToSuperview;
// 0x91b44 encoding: v20@0:8B16
- (id /* see encoding for actual type */)showUsingAnimation:(id)arg1;
// 0x91d50 encoding: v20@0:8B16
- (id /* see encoding for actual type */)hideUsingAnimation:(id)arg1;
// 0x91ef8 encoding: v36@0:8B16q20@?28
- (id /* see encoding for actual type */)animateIn:(id)arg1 withType:(id)arg2 completion:(id)arg3;
// 0x92240 encoding: v16@0:8
- (id /* see encoding for actual type */)done;
// 0x92348 encoding: v16@0:8
- (id /* see encoding for actual type */)setupViews;
// 0x92b58 encoding: v16@0:8
- (id /* see encoding for actual type */)updateIndicators;
// 0x92f18 encoding: v24@0:8@16
- (id /* see encoding for actual type */)updateViewsForColor:(id)arg1;
// 0x93388 encoding: v16@0:8
- (id /* see encoding for actual type */)updateBezelMotionEffects;
// 0x936c8 encoding: v16@0:8
- (id /* see encoding for actual type */)updateConstraints;
// 0x9441c encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0x9447c encoding: v16@0:8
- (id /* see encoding for actual type */)updatePaddingConstraints;
// 0x946b8 encoding: v28@0:8f16@20
- (id /* see encoding for actual type */)applyPriority:(id)arg1 toConstraints:(id)arg2;
// 0x947d8 encoding: v24@0:8q16
- (id /* see encoding for actual type */)setMode:(id)arg1;
// 0x94800 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setCustomView:(id)arg1;
// 0x94884 encoding: v32@0:8{CGPoint=dd}16
- (id /* see encoding for actual type */)setOffset:(id)arg1;
// 0x948b8 encoding: v24@0:8d16
- (id /* see encoding for actual type */)setMargin:(id)arg1;
// 0x948e0 encoding: v32@0:8{CGSize=dd}16
- (id /* see encoding for actual type */)setMinSize:(id)arg1;
// 0x94914 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setSquare:(id)arg1;
// 0x9493c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setProgressObjectDisplayLink:(id)arg1;
// 0x94a18 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setProgressObject:(id)arg1;
// 0x94a88 encoding: v20@0:8f16
- (id /* see encoding for actual type */)setProgress:(id)arg1;
// 0x94b60 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setContentColor:(id)arg1;
// 0x94be4 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setDefaultMotionEffectsEnabled:(id)arg1;
// 0x94c0c encoding: v20@0:8B16
- (id /* see encoding for actual type */)setNSProgressDisplayLinkEnabled:(id)arg1;
// 0x94ce0 encoding: v16@0:8
- (id /* see encoding for actual type */)updateProgressFromProgressObject;
// 0x94d38 encoding: v16@0:8
- (id /* see encoding for actual type */)registerForNotifications;
// 0x94da0 encoding: v16@0:8
- (id /* see encoding for actual type */)unregisterFromNotifications;
// 0x94e00 encoding: v24@0:8@16
- (id /* see encoding for actual type */)statusBarOrientationDidChange:(id)arg1;
// 0x94e50 encoding: v20@0:8B16
- (id /* see encoding for actual type */)updateForCurrentOrientationAnimated:(id)arg1;
// 0x94ee0 encoding: @16@0:8
- (id /* see encoding for actual type */)delegate;
// 0x94f00 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setDelegate:(id)arg1;
// 0x94f14 encoding: @?16@0:8
- (id /* see encoding for actual type */)completionBlock;
// 0x94f24 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)setCompletionBlock:(id)arg1;
// 0x94f30 encoding: d16@0:8
- (id /* see encoding for actual type */)graceTime;
// 0x94f40 encoding: v24@0:8d16
- (id /* see encoding for actual type */)setGraceTime:(id)arg1;
// 0x94f50 encoding: d16@0:8
- (id /* see encoding for actual type */)minShowTime;
// 0x94f60 encoding: v24@0:8d16
- (id /* see encoding for actual type */)setMinShowTime:(id)arg1;
// 0x94f70 encoding: B16@0:8
- (id /* see encoding for actual type */)removeFromSuperViewOnHide;
// 0x94f80 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setRemoveFromSuperViewOnHide:(id)arg1;
// 0x94f90 encoding: q16@0:8
- (id /* see encoding for actual type */)mode;
// 0x94fa0 encoding: @16@0:8
- (id /* see encoding for actual type */)contentColor;
// 0x94fb0 encoding: q16@0:8
- (id /* see encoding for actual type */)animationType;
// 0x94fc0 encoding: v24@0:8q16
- (id /* see encoding for actual type */)setAnimationType:(id)arg1;
// 0x94fd0 encoding: {CGPoint=dd}16@0:8
- (id /* see encoding for actual type */)offset;
// 0x94fe4 encoding: d16@0:8
- (id /* see encoding for actual type */)margin;
// 0x94ff4 encoding: {CGSize=dd}16@0:8
- (id /* see encoding for actual type */)minSize;
// 0x95008 encoding: B16@0:8
- (id /* see encoding for actual type */)isSquare;
// 0x95018 encoding: B16@0:8
- (id /* see encoding for actual type */)areDefaultMotionEffectsEnabled;
// 0x95028 encoding: f16@0:8
- (id /* see encoding for actual type */)progress;
// 0x95038 encoding: @16@0:8
- (id /* see encoding for actual type */)progressObject;
// 0x95048 encoding: @16@0:8
- (id /* see encoding for actual type */)bezelView;
// 0x95058 encoding: @16@0:8
- (id /* see encoding for actual type */)backgroundView;
// 0x95068 encoding: @16@0:8
- (id /* see encoding for actual type */)customView;
// 0x95078 encoding: @16@0:8
- (id /* see encoding for actual type */)label;
// 0x95088 encoding: @16@0:8
- (id /* see encoding for actual type */)detailsLabel;
// 0x95098 encoding: @16@0:8
- (id /* see encoding for actual type */)button;
// 0x950a8 encoding: @16@0:8
- (id /* see encoding for actual type */)hideButton;
// 0x950b8 encoding: B16@0:8
- (id /* see encoding for actual type */)useAnimation;
// 0x950c8 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setUseAnimation:(id)arg1;
// 0x950d8 encoding: B16@0:8
- (id /* see encoding for actual type */)hasFinished;
// 0x950e8 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setFinished:(id)arg1;
// 0x950f8 encoding: @16@0:8
- (id /* see encoding for actual type */)indicator;
// 0x95108 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setIndicator:(id)arg1;
// 0x9511c encoding: @16@0:8
- (id /* see encoding for actual type */)showStarted;
// 0x9512c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setShowStarted:(id)arg1;
// 0x95140 encoding: @16@0:8
- (id /* see encoding for actual type */)paddingConstraints;
// 0x95150 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setPaddingConstraints:(id)arg1;
// 0x95164 encoding: @16@0:8
- (id /* see encoding for actual type */)bezelConstraints;
// 0x95174 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setBezelConstraints:(id)arg1;
// 0x95188 encoding: @16@0:8
- (id /* see encoding for actual type */)topSpacer;
// 0x95198 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTopSpacer:(id)arg1;
// 0x951ac encoding: @16@0:8
- (id /* see encoding for actual type */)bottomSpacer;
// 0x951bc encoding: v24@0:8@16
- (id /* see encoding for actual type */)setBottomSpacer:(id)arg1;
// 0x951d0 encoding: @16@0:8
- (id /* see encoding for actual type */)graceTimer;
// 0x951f0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setGraceTimer:(id)arg1;
// 0x95204 encoding: @16@0:8
- (id /* see encoding for actual type */)minShowTimer;
// 0x95224 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setMinShowTimer:(id)arg1;
// 0x95238 encoding: @16@0:8
- (id /* see encoding for actual type */)hideDelayTimer;
// 0x95258 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setHideDelayTimer:(id)arg1;
// 0x9526c encoding: @16@0:8
- (id /* see encoding for actual type */)progressObjectDisplayLink;
// 0x9528c encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0x90de4 encoding: @28@0:8@16B24
+ (id /* see encoding for actual type */)showHUDAddedTo:(id)arg1 animated:(id)arg2;
// 0x90e78 encoding: B28@0:8@16B24
+ (id /* see encoding for actual type */)hideHUDForView:(id)arg1 animated:(id)arg2;
// 0x90eec encoding: @24@0:8@16
+ (id /* see encoding for actual type */)HUDForView:(id)arg1;
@end

@interface MBRoundProgressView /* superclass unresolved */
// 0x95434 encoding: @16@0:8
- (id /* see encoding for actual type */)init;
// 0x95454 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0x95578 encoding: {CGSize=dd}16@0:8
- (id /* see encoding for actual type */)intrinsicContentSize;
// 0x95588 encoding: v20@0:8f16
- (id /* see encoding for actual type */)setProgress:(id)arg1;
// 0x955b0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setProgressTintColor:(id)arg1;
// 0x956e0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setBackgroundTintColor:(id)arg1;
// 0x95810 encoding: v48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)drawRect:(id)arg1;
// 0x95bc8 encoding: f16@0:8
- (id /* see encoding for actual type */)progress;
// 0x95bd8 encoding: @16@0:8
- (id /* see encoding for actual type */)progressTintColor;
// 0x95be8 encoding: @16@0:8
- (id /* see encoding for actual type */)backgroundTintColor;
// 0x95bf8 encoding: B16@0:8
- (id /* see encoding for actual type */)isAnnular;
// 0x95c08 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setAnnular:(id)arg1;
// 0x95c18 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface MBBarProgressView /* superclass unresolved */
// 0x95c58 encoding: @16@0:8
- (id /* see encoding for actual type */)init;
// 0x95c78 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0x95db4 encoding: {CGSize=dd}16@0:8
- (id /* see encoding for actual type */)intrinsicContentSize;
// 0x95dc4 encoding: v20@0:8f16
- (id /* see encoding for actual type */)setProgress:(id)arg1;
// 0x95dec encoding: v24@0:8@16
- (id /* see encoding for actual type */)setProgressColor:(id)arg1;
// 0x95f1c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setProgressRemainingColor:(id)arg1;
// 0x9604c encoding: v48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)drawRect:(id)arg1;
// 0x9644c encoding: f16@0:8
- (id /* see encoding for actual type */)progress;
// 0x9645c encoding: @16@0:8
- (id /* see encoding for actual type */)lineColor;
// 0x9646c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setLineColor:(id)arg1;
// 0x96480 encoding: @16@0:8
- (id /* see encoding for actual type */)progressRemainingColor;
// 0x96490 encoding: @16@0:8
- (id /* see encoding for actual type */)progressColor;
// 0x964a0 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface MBBackgroundView /* superclass unresolved */
// 0x964f4 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0x965c0 encoding: {CGSize=dd}16@0:8
- (id /* see encoding for actual type */)intrinsicContentSize;
// 0x965d0 encoding: v24@0:8q16
- (id /* see encoding for actual type */)setStyle:(id)arg1;
// 0x965f8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setColor:(id)arg1;
// 0x9672c encoding: v24@0:8q16
- (id /* see encoding for actual type */)setBlurEffectStyle:(id)arg1;
// 0x96754 encoding: v16@0:8
- (id /* see encoding for actual type */)updateForBackgroundStyle;
// 0x9693c encoding: v24@0:8@16
- (id /* see encoding for actual type */)updateViewsForColor:(id)arg1;
// 0x96998 encoding: q16@0:8
- (id /* see encoding for actual type */)style;
// 0x969a8 encoding: q16@0:8
- (id /* see encoding for actual type */)blurEffectStyle;
// 0x969b8 encoding: @16@0:8
- (id /* see encoding for actual type */)color;
// 0x969c8 encoding: @16@0:8
- (id /* see encoding for actual type */)effectView;
// 0x969d8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setEffectView:(id)arg1;
// 0x969e4 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface MBProgressHUDRoundedButton /* superclass unresolved */
// 0x96a24 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0x96aa0 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0x96b3c encoding: {CGSize=dd}16@0:8
- (id /* see encoding for actual type */)intrinsicContentSize;
// 0x96ba4 encoding: v32@0:8@16Q24
- (id /* see encoding for actual type */)setTitleColor:(id)arg1 forState:(id)arg2;
// 0x96c84 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setHighlighted:(id)arg1;
@end

@interface MBProgressHUDRoundedButton2 /* superclass unresolved */
// 0x96d58 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0x96d8c encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0x96e28 encoding: {CGSize=dd}16@0:8
- (id /* see encoding for actual type */)intrinsicContentSize;
// 0x96e90 encoding: v32@0:8@16Q24
- (id /* see encoding for actual type */)setTitleColor:(id)arg1 forState:(id)arg2;
// 0x96f70 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setHighlighted:(id)arg1;
@end

@interface ABMenuActionItem /* superclass unresolved */
// 0x9ab38 encoding: @40@0:8@16q24@32
+ (id /* see encoding for actual type */)actionItemWithTitle:(id)arg1 style:(id)arg2 action:(id)arg3;
@end

@interface ABMenuViewController /* superclass unresolved */
// 0x9ac90 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)initWithTitle:(id)arg1 actionItems:(id)arg2;
// 0x9ad14 encoding: @24@0:8@16
- (id /* see encoding for actual type */)initWithActionItems:(id)arg1;
// 0x9ad48 encoding: v36@0:8@16B24@?28
- (id /* see encoding for actual type */)presentedFromViewController:(id)arg1 animated:(id)arg2 completion:(id)arg3;
// 0x9b228 encoding: @16@0:8
- (id /* see encoding for actual type */)actionTitle;
// 0x9b238 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setActionTitle:(id)arg1;
// 0x9b24c encoding: @16@0:8
- (id /* see encoding for actual type */)items;
// 0x9b25c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setItems:(id)arg1;
// 0x9b270 encoding: @16@0:8
- (id /* see encoding for actual type */)delegate;
// 0x9b290 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setDelegate:(id)arg1;
// 0x9b2a4 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLSystemAlertController /* superclass unresolved */
// 0x9b2f4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)traitCollectionDidChange:(id)arg1;
// 0x9b3b8 encoding: v16@0:8
- (id /* see encoding for actual type */)updateActionColors;
@end

@interface DLAACAudioConverter /* superclass unresolved */
// 0x9df78 encoding: v24@0:8@16
- (id /* see encoding for actual type */)showDocumentPickerWithDelegate:(id)arg1;
// 0x9e0c4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)showImagePickerWithDelegate:(id)arg1;
// 0x9e220 encoding: v32@0:8@16@24
- (id /* see encoding for actual type */)documentPicker:(id)arg1 didPickDocumentsAtURLs:(id)arg2;
// 0x9edfc encoding: v32@0:8@16@24
- (id /* see encoding for actual type */)imagePickerController:(id)arg1 didFinishPickingMediaWithInfo:(id)arg2;
// 0x9f600 encoding: @16@0:8
- (id /* see encoding for actual type */)threadViewController;
// 0x9f60c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setThreadViewController:(id)arg1;
// 0x9f614 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0x9ded0 encoding: @16@0:8
+ (id /* see encoding for actual type */)sharedInstance;
@end

@interface DLButton /* superclass unresolved */
// 0x9f620 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0x9f688 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)actionHandler:(id)arg1;
// 0x9f6c0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)didPressButton:(id)arg1;
// 0x9f6dc encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLTapGestureRecognizer /* superclass unresolved */
// 0x9f6f0 encoding: @24@0:8@?16
- (id /* see encoding for actual type */)initWithAction:(id)arg1;
// 0x9f75c encoding: v24@0:8@16
- (id /* see encoding for actual type */)didTap:(id)arg1;
// 0x9f778 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLBarButtonItem /* superclass unresolved */
// 0x9f78c encoding: @40@0:8@16q24@?32
- (id /* see encoding for actual type */)initWithTitle:(id)arg1 style:(id)arg2 action:(id)arg3;
// 0x9f82c encoding: @40@0:8@16q24@?32
- (id /* see encoding for actual type */)initWithImage:(id)arg1 style:(id)arg2 action:(id)arg3;
// 0x9f8cc encoding: v24@0:8@16
- (id /* see encoding for actual type */)didPressBarButton:(id)arg1;
// 0x9f8e8 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLAuthenticationView /* superclass unresolved */
// 0x9f8fc encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0x9fa50 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0x9faa8 encoding: v16@0:8
- (id /* see encoding for actual type */)setupBlurView;
// 0x9fcb4 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)contextAuthenticated:(id)arg1;
// 0x9fec4 encoding: @16@0:8
- (id /* see encoding for actual type */)context;
// 0x9fed4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setContext:(id)arg1;
// 0x9fee8 encoding: B16@0:8
- (id /* see encoding for actual type */)isAuthenticated;
// 0x9fef8 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setAuthenticated:(id)arg1;
// 0x9ff08 encoding: @16@0:8
- (id /* see encoding for actual type */)dlBlurView;
// 0x9ff18 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setDlBlurView:(id)arg1;
// 0x9ff2c encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLDownloadManager /* superclass unresolved */
// 0x9ff6c encoding: v24@0:8@16
+ (id /* see encoding for actual type */)mergeVideosAsOneVideoWithHud:(id)arg1;
// 0xa0788 encoding: v36@0:8@16B24@28
+ (id /* see encoding for actual type */)exportVideoAfterMerged:(id)arg1 isSupportAudio:(id)arg2 withHud:(id)arg3;
// 0xa09cc encoding: v32@0:8@16@?24
+ (id /* see encoding for actual type */)removeAudioFromVideoURL:(id)arg1 handler:(id)arg2;
// 0xa0d80 encoding: B16@0:8
+ (id /* see encoding for actual type */)isAnyMediaHaveAudio;
// 0xa0f60 encoding: @16@0:8
+ (id /* see encoding for actual type */)allMultiMediaFiles;
// 0xa0ff8 encoding: v16@0:8
+ (id /* see encoding for actual type */)removeAllMultiFilesInFolder;
// 0xa120c encoding: @16@0:8
+ (id /* see encoding for actual type */)multiMediaPath;
@end

@interface DLDownloaderMinimizeView /* superclass unresolved */
// 0xa1348 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0xa13a0 encoding: v16@0:8
- (id /* see encoding for actual type */)setupViews;
// 0xa1788 encoding: @16@0:8
- (id /* see encoding for actual type */)percentLabel;
// 0xa1798 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setPercentLabel:(id)arg1;
// 0xa17ac encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLInstaDownloader /* superclass unresolved */
// 0xa17c0 encoding: v36@0:8@16B24@?28
- (id /* see encoding for actual type */)downloadMultibileItems:(id)arg1 isNeedMerge:(id)arg2 completion:(id)arg3;
// 0xa2518 encoding: v32@0:8@16Q24
- (id /* see encoding for actual type */)downloadMediaURLString:(id)arg1 mediaType:(id)arg2;
// 0xa3184 encoding: v16@0:8
- (id /* see encoding for actual type */)setupMinimizeView;
// 0xa33c4 encoding: v16@0:8
- (id /* see encoding for actual type */)cancel;
// 0xa342c encoding: v16@0:8
- (id /* see encoding for actual type */)DLHUDHide;
// 0xa3484 encoding: v16@0:8
- (id /* see encoding for actual type */)whenHideHUD;
// 0xa3514 encoding: v16@0:8
- (id /* see encoding for actual type */)showHUDAgain;
// 0xa3598 encoding: v16@0:8
- (id /* see encoding for actual type */)hideHUDIfNeeded;
// 0xa35dc encoding: v16@0:8
- (id /* see encoding for actual type */)removeViewAndHideHUD;
// 0xa366c encoding: v40@0:8@16@24@32
- (id /* see encoding for actual type */)URLSession:(id)arg1 downloadTask:(id)arg2 didFinishDownloadingToURL:(id)arg3;
// 0xa3898 encoding: v24@0:8@16
- (id /* see encoding for actual type */)didFinishDownloadingToPath:(id)arg1;
// 0xa3a4c encoding: v56@0:8@16@24q32q40q48
- (id /* see encoding for actual type */)URLSession:(id)arg1 downloadTask:(id)arg2 didWriteData:(id)arg3 totalBytesWritten:(id)arg4 totalBytesExpectedToWrite:(id)arg5;
// 0xa42e8 encoding: @16@0:8
- (id /* see encoding for actual type */)hud;
// 0xa42f0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setHud:(id)arg1;
// 0xa42fc encoding: @16@0:8
- (id /* see encoding for actual type */)task;
// 0xa4304 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTask:(id)arg1;
// 0xa4310 encoding: @16@0:8
- (id /* see encoding for actual type */)minimizeView;
// 0xa4318 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setMinimizeView:(id)arg1;
// 0xa4324 encoding: Q16@0:8
- (id /* see encoding for actual type */)mediaType;
// 0xa432c encoding: v24@0:8Q16
- (id /* see encoding for actual type */)setMediaType:(id)arg1;
// 0xa4334 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xa3c8c encoding: v40@0:8@16@24@?32
+ (id /* see encoding for actual type */)downloadMedia:(id)arg1 filePath:(id)arg2 completion:(id)arg3;
// 0xa405c encoding: @16@0:8
+ (id /* see encoding for actual type */)documentsDirectoryPath;
// 0xa40b8 encoding: @24@0:8@16
+ (id /* see encoding for actual type */)imageTypeFromData:(id)arg1;
@end

@interface DLMediaData /* superclass unresolved */
// 0xa4370 encoding: v32@0:8@16@?24
- (id /* see encoding for actual type */)downloadImageFromUrl:(id)arg1 completion:(id)arg2;
// 0xa45c8 encoding: @24@0:8d16
- (id /* see encoding for actual type */)convertTimeToString:(id)arg1;
// 0xa467c encoding: @16@0:8
- (id /* see encoding for actual type */)coverUrl;
// 0xa4684 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setCoverUrl:(id)arg1;
// 0xa4690 encoding: @16@0:8
- (id /* see encoding for actual type */)url;
// 0xa4698 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setUrl:(id)arg1;
// 0xa46a4 encoding: @16@0:8
- (id /* see encoding for actual type */)coverImage;
// 0xa46ac encoding: v24@0:8@16
- (id /* see encoding for actual type */)setCoverImage:(id)arg1;
// 0xa46b8 encoding: Q16@0:8
- (id /* see encoding for actual type */)mediaType;
// 0xa46c0 encoding: v24@0:8Q16
- (id /* see encoding for actual type */)setMediaType:(id)arg1;
// 0xa46c8 encoding: d16@0:8
- (id /* see encoding for actual type */)duration;
// 0xa46d0 encoding: v24@0:8d16
- (id /* see encoding for actual type */)setDuration:(id)arg1;
// 0xa46d8 encoding: d16@0:8
- (id /* see encoding for actual type */)takenAtDate;
// 0xa46e0 encoding: v24@0:8d16
- (id /* see encoding for actual type */)setTakenAtDate:(id)arg1;
// 0xa46e8 encoding: B16@0:8
- (id /* see encoding for actual type */)isFetching;
// 0xa46f0 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setFetching:(id)arg1;
// 0xa46f8 encoding: B16@0:8
- (id /* see encoding for actual type */)isSelected;
// 0xa4700 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setSelect:(id)arg1;
// 0xa4708 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLSaveMedia /* superclass unresolved */
// 0xa4744 encoding: v24@0:8@16
+ (id /* see encoding for actual type */)shareMediaFile:(id)arg1;
// 0xa4a64 encoding: v36@0:8@16Q24B32
+ (id /* see encoding for actual type */)saveMediaOnCamera:(id)arg1 mediaType:(id)arg2 needShare:(id)arg3;
// 0xa4e88 encoding: v36@0:8@16Q24B32
+ (id /* see encoding for actual type */)saveMediaOnCamera:(id)arg1 mediaType:(id)arg2 showSuccess:(id)arg3;
// 0xa4eb0 encoding: v32@0:8@16Q24
+ (id /* see encoding for actual type */)saveMediaOnCamera:(id)arg1 mediaType:(id)arg2;
// 0xa4f20 encoding: v40@0:8@16Q24@?32
+ (id /* see encoding for actual type */)saveMediaOnCamera:(id)arg1 mediaType:(id)arg2 completion:(id)arg3;
// 0xa5244 encoding: v24@0:8Q16
+ (id /* see encoding for actual type */)showHUDInThreadWithState:(id)arg1;
// 0xa52d0 encoding: v16@0:8
+ (id /* see encoding for actual type */)clearCacheIfNeeded;
@end

@interface DLInfoSheetViewController /* superclass unresolved */
// 0xa5418 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)initWithTitle:(id)arg1 info:(id)arg2;
// 0xa54cc encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLoad;
// 0xa5e6c encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLayoutSubviews;
// 0xa6204 encoding: @16@0:8
- (id /* see encoding for actual type */)titleInfo;
// 0xa6214 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTitleInfo:(id)arg1;
// 0xa6228 encoding: @16@0:8
- (id /* see encoding for actual type */)info;
// 0xa6238 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setInfo:(id)arg1;
// 0xa624c encoding: @16@0:8
- (id /* see encoding for actual type */)titleLabel;
// 0xa625c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTitleLabel:(id)arg1;
// 0xa6270 encoding: @16@0:8
- (id /* see encoding for actual type */)infoLabel;
// 0xa6280 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setInfoLabel:(id)arg1;
// 0xa6294 encoding: @16@0:8
- (id /* see encoding for actual type */)iconImageView;
// 0xa62a4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setIconImageView:(id)arg1;
// 0xa62b8 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLInfoSheetPresentationController /* superclass unresolved */
// 0xa6334 encoding: {CGRect={CGPoint=dd}{CGSize=dd}}16@0:8
- (id /* see encoding for actual type */)frameOfPresentedViewInContainerView;
// 0xa63fc encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)initWithPresentedViewController:(id)arg1 presentingViewController:(id)arg2;
// 0xa6538 encoding: v16@0:8
- (id /* see encoding for actual type */)containerViewWillLayoutSubviews;
// 0xa67bc encoding: v16@0:8
- (id /* see encoding for actual type */)presentationTransitionWillBegin;
// 0xa6990 encoding: v16@0:8
- (id /* see encoding for actual type */)dismissalTransitionWillBegin;
// 0xa6a88 encoding: v24@0:8@16
- (id /* see encoding for actual type */)dismissCustomVC:(id)arg1;
// 0xa6afc encoding: d16@0:8
- (id /* see encoding for actual type */)bottomHeight;
// 0xa6b50 encoding: @16@0:8
- (id /* see encoding for actual type */)dimmingView;
// 0xa6b60 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setDimmingView:(id)arg1;
// 0xa6b74 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLInfoSheetControllerDelegate /* superclass unresolved */
// 0xa6b88 encoding: @40@0:8@16@24@32
- (id /* see encoding for actual type */)presentationControllerForPresentedViewController:(id)arg1 presentingViewController:(id)arg2 sourceViewController:(id)arg3;
@end

@interface MyCustomPresentationController /* superclass unresolved */
// 0xa6cb4 encoding: v16@0:8
- (id /* see encoding for actual type */)presentationTransitionWillBegin;
// 0xa6e60 encoding: v16@0:8
- (id /* see encoding for actual type */)containerViewWillLayoutSubviews;
// 0xa6f98 encoding: v20@0:8B16
- (id /* see encoding for actual type */)presentationTransitionDidEnd:(id)arg1;
// 0xa7010 encoding: v16@0:8
- (id /* see encoding for actual type */)dismissalTransitionWillBegin;
// 0xa71a8 encoding: v20@0:8B16
- (id /* see encoding for actual type */)dismissalTransitionDidEnd:(id)arg1;
// 0xa7220 encoding: @16@0:8
- (id /* see encoding for actual type */)dimmingView;
// 0xa7230 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setDimmingView:(id)arg1;
// 0xa723c encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLMaxAlertButton /* superclass unresolved */
// 0xa7250 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0xa75bc encoding: v24@0:8@?16
- (id /* see encoding for actual type */)actionHandler:(id)arg1;
// 0xa7668 encoding: v16@0:8
- (id /* see encoding for actual type */)didPressButton;
// 0xa76e4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)traitCollectionDidChange:(id)arg1;
// 0xa78b4 encoding: @?16@0:8
- (id /* see encoding for actual type */)handler;
// 0xa78c4 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLMaxAlertAction /* superclass unresolved */
// 0xa7904 encoding: @32@0:8@16@?24
- (id /* see encoding for actual type */)initWithTitle:(id)arg1 action:(id)arg2;
// 0xa79ac encoding: @16@0:8
- (id /* see encoding for actual type */)title;
// 0xa79b4 encoding: @?16@0:8
- (id /* see encoding for actual type */)actionHandler;
// 0xa79bc encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLMaxAlertTextView /* superclass unresolved */
// 0xa79ec encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xa7a78 encoding: {CGSize=dd}16@0:8
- (id /* see encoding for actual type */)intrinsicContentSize;
@end

@interface DLMaxAlertViewController /* superclass unresolved */
// 0xa7b18 encoding: v16@0:8
- (id /* see encoding for actual type */)viewWillLayoutSubviews;
// 0xa7e14 encoding: @40@0:8@16@24@32
- (id /* see encoding for actual type */)initWithTweakName:(id)arg1 message:(id)arg2 actions:(id)arg3;
// 0xa7f18 encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLoad;
// 0xa92a4 encoding: @40@0:8@16@24@32
- (id /* see encoding for actual type */)presentationControllerForPresentedViewController:(id)arg1 presentingViewController:(id)arg2 sourceViewController:(id)arg3;
// 0xa931c encoding: v16@0:8
- (id /* see encoding for actual type */)dismissAlertController;
// 0xa9330 encoding: v24@0:8@16
- (id /* see encoding for actual type */)traitCollectionDidChange:(id)arg1;
// 0xa95b4 encoding: v16@0:8
- (id /* see encoding for actual type */)applyCustomFontForBodyText;
// 0xa9af8 encoding: d16@0:8
- (id /* see encoding for actual type */)cornerRadius;
// 0xa9b0c encoding: v24@0:8d16
- (id /* see encoding for actual type */)setCornerRadius:(id)arg1;
// 0xa9b20 encoding: @16@0:8
- (id /* see encoding for actual type */)containerView;
// 0xa9b30 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setContainerView:(id)arg1;
// 0xa9b3c encoding: @16@0:8
- (id /* see encoding for actual type */)titleLabel;
// 0xa9b4c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTitleLabel:(id)arg1;
// 0xa9b58 encoding: @16@0:8
- (id /* see encoding for actual type */)tweakName;
// 0xa9b68 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTweakName:(id)arg1;
// 0xa9b74 encoding: @16@0:8
- (id /* see encoding for actual type */)message;
// 0xa9b84 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setMessage:(id)arg1;
// 0xa9b90 encoding: @16@0:8
- (id /* see encoding for actual type */)bodyText;
// 0xa9ba0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setBodyText:(id)arg1;
// 0xa9bac encoding: @16@0:8
- (id /* see encoding for actual type */)actions;
// 0xa9bbc encoding: v24@0:8@16
- (id /* see encoding for actual type */)setActions:(id)arg1;
// 0xa9bc8 encoding: @16@0:8
- (id /* see encoding for actual type */)containerViewHeightConstraint;
// 0xa9bd8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setContainerViewHeightConstraint:(id)arg1;
// 0xa9be4 encoding: @16@0:8
- (id /* see encoding for actual type */)containerViewWidthConstraint;
// 0xa9bf4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setContainerViewWidthConstraint:(id)arg1;
// 0xa9c00 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLMentionViewCell /* superclass unresolved */
// 0xa9cb8 encoding: @32@0:8q16@24
- (id /* see encoding for actual type */)initWithStyle:(id)arg1 reuseIdentifier:(id)arg2;
// 0xa9d44 encoding: v16@0:8
- (id /* see encoding for actual type */)prepareForReuse;
// 0xa9db8 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xaa238 encoding: v16@0:8
- (id /* see encoding for actual type */)setupViews;
// 0xab180 encoding: v24@0:8@16
- (id /* see encoding for actual type */)avatarImageTapped:(id)arg1;
// 0xab214 encoding: @?16@0:8
- (id /* see encoding for actual type */)avatarImageTapAction;
// 0xab224 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)setAvatarImageTapAction:(id)arg1;
// 0xab230 encoding: @16@0:8
- (id /* see encoding for actual type */)avatarImageView;
// 0xab240 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setAvatarImageView:(id)arg1;
// 0xab254 encoding: @16@0:8
- (id /* see encoding for actual type */)usernameLabel;
// 0xab264 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setUsernameLabel:(id)arg1;
// 0xab278 encoding: @16@0:8
- (id /* see encoding for actual type */)fullnameLabel;
// 0xab288 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setFullnameLabel:(id)arg1;
// 0xab29c encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLMentionsViewController /* superclass unresolved */
// 0xab304 encoding: @24@0:8@16
- (id /* see encoding for actual type */)initWithUsers:(id)arg1;
// 0xab388 encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLayoutSubviews;
// 0xab56c encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLoad;
// 0xac198 encoding: v32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 didSelectRowAtIndexPath:(id)arg2;
// 0xac2c4 encoding: d32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 heightForRowAtIndexPath:(id)arg2;
// 0xac2d0 encoding: q24@0:8@16
- (id /* see encoding for actual type */)numberOfSectionsInTableView:(id)arg1;
// 0xac2d8 encoding: q32@0:8@16q24
- (id /* see encoding for actual type */)tableView:(id)arg1 numberOfRowsInSection:(id)arg2;
// 0xac324 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 cellForRowAtIndexPath:(id)arg2;
// 0xac908 encoding: @16@0:8
- (id /* see encoding for actual type */)tableView;
// 0xac918 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTableView:(id)arg1;
// 0xac92c encoding: @16@0:8
- (id /* see encoding for actual type */)users;
// 0xac93c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setUsers:(id)arg1;
// 0xac950 encoding: @16@0:8
- (id /* see encoding for actual type */)titleLabel;
// 0xac960 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTitleLabel:(id)arg1;
// 0xac974 encoding: @16@0:8
- (id /* see encoding for actual type */)emptyLabel;
// 0xac984 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setEmptyLabel:(id)arg1;
// 0xac998 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLUser /* superclass unresolved */
// 0xaca00 encoding: v32@0:8@16@?24
- (id /* see encoding for actual type */)downloadAvatarFromUrl:(id)arg1 completion:(id)arg2;
// 0xacd10 encoding: @16@0:8
- (id /* see encoding for actual type */)pk;
// 0xacd18 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setPk:(id)arg1;
// 0xacd24 encoding: @16@0:8
- (id /* see encoding for actual type */)fullname;
// 0xacd2c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setFullname:(id)arg1;
// 0xacd38 encoding: @16@0:8
- (id /* see encoding for actual type */)username;
// 0xacd40 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setUsername:(id)arg1;
// 0xacd4c encoding: @16@0:8
- (id /* see encoding for actual type */)avatarURL;
// 0xacd54 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setAvatarURL:(id)arg1;
// 0xacd60 encoding: @16@0:8
- (id /* see encoding for actual type */)avatarImage;
// 0xacd68 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setAvatarImage:(id)arg1;
// 0xacd74 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLVisualEffectView /* superclass unresolved */
// 0xad380 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
@end

@interface DLPopupViewController /* superclass unresolved */
// 0xacdc8 encoding: v16@0:8
- (id /* see encoding for actual type */)showController;
// 0xacf14 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)hideController:(id)arg1;
// 0xad0a0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)panGestureRecognizerHandler:(id)arg1;
// 0xad370 encoding: Q16@0:8
- (id /* see encoding for actual type */)supportedInterfaceOrientations;
// 0xad378 encoding: q16@0:8
- (id /* see encoding for actual type */)preferredInterfaceOrientationForPresentation;
// 0xad514 encoding: @24@0:8d16
- (id /* see encoding for actual type */)initWithCustomHeight:(id)arg1;
// 0xad5a0 encoding: d16@0:8
- (id /* see encoding for actual type */)popupViewHeight;
// 0xad634 encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLayoutSubviews;
// 0xad8a4 encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLoad;
// 0xad914 encoding: v20@0:8B16
- (id /* see encoding for actual type */)viewWillAppear:(id)arg1;
// 0xad964 encoding: v20@0:8B16
- (id /* see encoding for actual type */)viewDidAppear:(id)arg1;
// 0xad9b0 encoding: v16@0:8
- (id /* see encoding for actual type */)setupBackgroundView;
// 0xadba0 encoding: v16@0:8
- (id /* see encoding for actual type */)setupBlurView;
// 0xadfcc encoding: v16@0:8
- (id /* see encoding for actual type */)setupPopupView;
// 0xae428 encoding: v16@0:8
- (id /* see encoding for actual type */)dismissPopup;
// 0xae4f8 encoding: @16@0:8
- (id /* see encoding for actual type */)popupView;
// 0xae508 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setPopupView:(id)arg1;
// 0xae51c encoding: {CGPoint=dd}16@0:8
- (id /* see encoding for actual type */)initialTouchPoint;
// 0xae530 encoding: v32@0:8{CGPoint=dd}16
- (id /* see encoding for actual type */)setInitialTouchPoint:(id)arg1;
// 0xae544 encoding: @16@0:8
- (id /* see encoding for actual type */)blurWidthLayoutConstraint;
// 0xae554 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setBlurWidthLayoutConstraint:(id)arg1;
// 0xae568 encoding: d16@0:8
- (id /* see encoding for actual type */)customHeight;
// 0xae578 encoding: v24@0:8d16
- (id /* see encoding for actual type */)setCustomHeight:(id)arg1;
// 0xae588 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface FRPCell /* superclass unresolved */
// 0xae664 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)initWithTitle:(id)arg1 setting:(id)arg2;
// 0xae784 encoding: v24@0:8@16
- (id /* see encoding for actual type */)didSelectFromTable:(id)arg1;
// 0xae788 encoding: @16@0:8
- (id /* see encoding for actual type */)tintUIColor;
// 0xae798 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTintUIColor:(id)arg1;
// 0xae7ac encoding: @16@0:8
- (id /* see encoding for actual type */)setting;
// 0xae7bc encoding: v24@0:8@16
- (id /* see encoding for actual type */)setSetting:(id)arg1;
// 0xae7d0 encoding: @16@0:8
- (id /* see encoding for actual type */)title;
// 0xae7e0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTitle:(id)arg1;
// 0xae7f4 encoding: @16@0:8
- (id /* see encoding for actual type */)postNotification;
// 0xae804 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setPostNotification:(id)arg1;
// 0xae818 encoding: @?16@0:8
- (id /* see encoding for actual type */)valueChanged;
// 0xae828 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)setValueChanged:(id)arg1;
// 0xae834 encoding: i16@0:8
- (id /* see encoding for actual type */)height;
// 0xae844 encoding: v20@0:8i16
- (id /* see encoding for actual type */)setHeight:(id)arg1;
// 0xae854 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xae5f0 encoding: @32@0:8@16@24
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2;
@end

@interface FRPDeveloperCell /* superclass unresolved */
// 0xae998 encoding: @48@0:8@16@24@32@40
- (id /* see encoding for actual type */)cellWithTitle:(id)arg1 detail:(id)arg2 image:(id)arg3 url:(id)arg4;
// 0xaec3c encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xaecb0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)didSelectFromTable:(id)arg1;
// 0xaee08 encoding: @16@0:8
- (id /* see encoding for actual type */)url;
// 0xaee18 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setUrl:(id)arg1;
// 0xaee2c encoding: @16@0:8
- (id /* see encoding for actual type */)image;
// 0xaee3c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setImage:(id)arg1;
// 0xaee50 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xae8d0 encoding: @48@0:8@16@24@32@40
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 detail:(id)arg2 image:(id)arg3 url:(id)arg4;
@end

@interface FRPLinkCell /* superclass unresolved */
// 0xaef18 encoding: @32@0:8@16@?24
- (id /* see encoding for actual type */)cellWithTitle:(id)arg1 selectedBlock:(id)arg2;
// 0xaefb4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)didSelectFromTable:(id)arg1;
// 0xaf0c4 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xaee90 encoding: @32@0:8@16@?24
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 selectedBlock:(id)arg2;
@end

@interface FRPListCell /* superclass unresolved */
// 0xaf210 encoding: @68@0:8@16@24@32@40B48@52@?60
- (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 items:(id)arg3 value:(id)arg4 popViewOnSelect:(id)arg5 postNotification:(id)arg6 changedBlock:(id)arg7;
// 0xaf5b0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)didSelectFromTable:(id)arg1;
// 0xafb20 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xafb54 encoding: @16@0:8
- (id /* see encoding for actual type */)items;
// 0xafb64 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setItems:(id)arg1;
// 0xafb78 encoding: @16@0:8
- (id /* see encoding for actual type */)values;
// 0xafb88 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setValues:(id)arg1;
// 0xafb9c encoding: B16@0:8
- (id /* see encoding for actual type */)popView;
// 0xafbac encoding: v20@0:8B16
- (id /* see encoding for actual type */)setPopView:(id)arg1;
// 0xafbbc encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xaf0f8 encoding: @68@0:8@16@24@32@40B48@52@?60
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 items:(id)arg3 value:(id)arg4 popViewOnSelect:(id)arg5 postNotification:(id)arg6 changedBlock:(id)arg7;
@end

@interface FRPSection /* superclass unresolved */
// 0xafc70 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)initWithTitle:(id)arg1 footer:(id)arg2;
// 0xafd4c encoding: v24@0:8@16
- (id /* see encoding for actual type */)addCell:(id)arg1;
// 0xafdb8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)removeCell:(id)arg1;
// 0xafe24 encoding: v24@0:8@16
- (id /* see encoding for actual type */)addCells:(id)arg1;
// 0xafe90 encoding: @16@0:8
- (id /* see encoding for actual type */)headerTitle;
// 0xafea0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setHeaderTitle:(id)arg1;
// 0xafeb4 encoding: @16@0:8
- (id /* see encoding for actual type */)footerTitle;
// 0xafec4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setFooterTitle:(id)arg1;
// 0xafed8 encoding: @16@0:8
- (id /* see encoding for actual type */)cells;
// 0xafee8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setCells:(id)arg1;
// 0xafefc encoding: @16@0:8
- (id /* see encoding for actual type */)tintUIColor;
// 0xaff0c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTintUIColor:(id)arg1;
// 0xaff20 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xafbfc encoding: @32@0:8@16@24
+ (id /* see encoding for actual type */)sectionWithTitle:(id)arg1 footer:(id)arg2;
@end

@interface FRPSegmentCell /* superclass unresolved */
// 0xb0270 encoding: @64@0:8@16@24@32@40@48@?56
- (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 values:(id)arg3 displayedValues:(id)arg4 postNotification:(id)arg5 changeBlock:(id)arg6;
// 0xb05a4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)segmentAction:(id)arg1;
// 0xb0728 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xb07c0 encoding: @16@0:8
- (id /* see encoding for actual type */)segment;
// 0xb07d0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setSegment:(id)arg1;
// 0xb07e4 encoding: @16@0:8
- (id /* see encoding for actual type */)values;
// 0xb07f4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setValues:(id)arg1;
// 0xb0808 encoding: @16@0:8
- (id /* see encoding for actual type */)displayedValues;
// 0xb0818 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setDisplayedValues:(id)arg1;
// 0xb082c encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xaff88 encoding: @56@0:8@16@24@32@40@?48
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 items:(id)arg3 postNotification:(id)arg4 changeBlock:(id)arg5;
// 0xb0078 encoding: @64@0:8@16@24@32@40@48@?56
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 values:(id)arg3 displayedValues:(id)arg4 postNotification:(id)arg5 changeBlock:(id)arg6;
// 0xb0180 encoding: @56@0:8@16@24@32@40@?48
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 values:(id)arg3 postNotification:(id)arg4 changeBlock:(id)arg5;
@end

@interface DLRadioSelectView /* superclass unresolved */
// 0xb0880 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xb0d70 encoding: B16@0:8
- (id /* see encoding for actual type */)checked;
// 0xb0d80 encoding: v20@0:8B16
- (id /* see encoding for actual type */)setChecked:(id)arg1;
// 0xb0d90 encoding: @16@0:8
- (id /* see encoding for actual type */)checkedDotLayer;
// 0xb0da0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setCheckedDotLayer:(id)arg1;
// 0xb0db4 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface FRPSelectListTable /* superclass unresolved */
// 0xb0dc8 encoding: v16@0:8
- (id /* see encoding for actual type */)viewWillLayoutSubviews;
// 0xb0eb8 encoding: @68@0:8q16@24@32@40@48B56@?60
- (id /* see encoding for actual type */)initWithStyle:(id)arg1 title:(id)arg2 items:(id)arg3 values:(id)arg4 currentValue:(id)arg5 popViewOnSelect:(id)arg6 changeBlock:(id)arg7;
// 0xb10a0 encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLoad;
// 0xb1294 encoding: q24@0:8@16
- (id /* see encoding for actual type */)numberOfSectionsInTableView:(id)arg1;
// 0xb129c encoding: q32@0:8@16q24
- (id /* see encoding for actual type */)tableView:(id)arg1 numberOfRowsInSection:(id)arg2;
// 0xb12b4 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 cellForRowAtIndexPath:(id)arg2;
// 0xb1588 encoding: d32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 heightForRowAtIndexPath:(id)arg2;
// 0xb1594 encoding: @32@0:8@16q24
- (id /* see encoding for actual type */)tableView:(id)arg1 viewForFooterInSection:(id)arg2;
// 0xb1790 encoding: v32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 didSelectRowAtIndexPath:(id)arg2;
// 0xb1a08 encoding: v16@0:8
- (id /* see encoding for actual type */)didReceiveMemoryWarning;
// 0xb1a3c encoding: @?16@0:8
- (id /* see encoding for actual type */)itemChanged;
// 0xb1a4c encoding: v24@0:8@?16
- (id /* see encoding for actual type */)setItemChanged:(id)arg1;
// 0xb1a58 encoding: @16@0:8
- (id /* see encoding for actual type */)tintUIColor;
// 0xb1a68 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTintUIColor:(id)arg1;
// 0xb1a74 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface FRPSettings /* superclass unresolved */
// 0xb1b78 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)initWithKey:(id)arg1 defaultValue:(id)arg2;
// 0xb1cd8 encoding: v48@0:8@16@24@32^v40
- (id /* see encoding for actual type */)observeValueForKeyPath:(id)arg1 ofObject:(id)arg2 change:(id)arg3 context:(id)arg4;
// 0xb1d54 encoding: @16@0:8
- (id /* see encoding for actual type */)value;
// 0xb1de8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setValue:(id)arg1;
// 0xb1f2c encoding: v24@0:8@16
- (id /* see encoding for actual type */)saveValue:(id)arg1;
// 0xb2050 encoding: @16@0:8
- (id /* see encoding for actual type */)key;
// 0xb2058 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setKey:(id)arg1;
// 0xb2064 encoding: @16@0:8
- (id /* see encoding for actual type */)fileSave;
// 0xb206c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setFileSave:(id)arg1;
// 0xb2078 encoding: @?16@0:8
- (id /* see encoding for actual type */)valueDidChangeBlock;
// 0xb2080 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)setValueDidChangeBlock:(id)arg1;
// 0xb2088 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xb1b04 encoding: @32@0:8@16@24
+ (id /* see encoding for actual type */)settingsWithKey:(id)arg1 defaultValue:(id)arg2;
@end

@interface FRPSliderCell /* superclass unresolved */
// 0xb21a4 encoding: @56@0:8@16@24f32f36@40@?48
- (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 min:(id)arg3 max:(id)arg4 postNotification:(id)arg5 changeBlock:(id)arg6;
// 0xb2a6c encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xb2f24 encoding: v24@0:8@16
- (id /* see encoding for actual type */)sliderChanged:(id)arg1;
// 0xb310c encoding: @16@0:8
- (id /* see encoding for actual type */)sliderCell;
// 0xb311c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setSliderCell:(id)arg1;
// 0xb3130 encoding: @16@0:8
- (id /* see encoding for actual type */)lLabel;
// 0xb3140 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setLLabel:(id)arg1;
// 0xb3154 encoding: @16@0:8
- (id /* see encoding for actual type */)rLabel;
// 0xb3164 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setRLabel:(id)arg1;
// 0xb3178 encoding: @16@0:8
- (id /* see encoding for actual type */)cLabel;
// 0xb3188 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setCLabel:(id)arg1;
// 0xb319c encoding: @16@0:8
- (id /* see encoding for actual type */)vLabel;
// 0xb31ac encoding: v24@0:8@16
- (id /* see encoding for actual type */)setVLabel:(id)arg1;
// 0xb31c0 encoding: f16@0:8
- (id /* see encoding for actual type */)min;
// 0xb31d0 encoding: v20@0:8f16
- (id /* see encoding for actual type */)setMin:(id)arg1;
// 0xb31e0 encoding: f16@0:8
- (id /* see encoding for actual type */)max;
// 0xb31f0 encoding: v20@0:8f16
- (id /* see encoding for actual type */)setMax:(id)arg1;
// 0xb3200 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xb20c4 encoding: @56@0:8@16@24f32f36@40@?48
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 min:(id)arg3 max:(id)arg4 postNotification:(id)arg5 changeBlock:(id)arg6;
@end

@interface FRPSwitchCell /* superclass unresolved */
// 0xb3344 encoding: @48@0:8@16@24@32@?40
- (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 postNotification:(id)arg3 changeBlock:(id)arg4;
// 0xb35a8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)switchChanged:(id)arg1;
// 0xb3704 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xb38c4 encoding: @16@0:8
- (id /* see encoding for actual type */)switchView;
// 0xb38d4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setSwitchView:(id)arg1;
// 0xb38e8 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xb327c encoding: @48@0:8@16@24@32@?40
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 postNotification:(id)arg3 changeBlock:(id)arg4;
@end

@interface FRPTextFieldCell /* superclass unresolved */
// 0xb39e8 encoding: @56@0:8@16@24@32@40@?48
- (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 placeholder:(id)arg3 postNotification:(id)arg4 changeBlock:(id)arg5;
// 0xb3d1c encoding: v24@0:8@16
- (id /* see encoding for actual type */)textFieldChanged:(id)arg1;
// 0xb3e5c encoding: B24@0:8@16
- (id /* see encoding for actual type */)textFieldShouldReturn:(id)arg1;
// 0xb3e80 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xb3f18 encoding: @16@0:8
- (id /* see encoding for actual type */)textField;
// 0xb3f28 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTextField:(id)arg1;
// 0xb3f3c encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xb38fc encoding: @56@0:8@16@24@32@40@?48
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 setting:(id)arg2 placeholder:(id)arg3 postNotification:(id)arg4 changeBlock:(id)arg5;
@end

@interface FRPValueCell /* superclass unresolved */
// 0xb3fd8 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)cellWithTitle:(id)arg1 detail:(id)arg2;
// 0xb3f50 encoding: @32@0:8@16@24
+ (id /* see encoding for actual type */)cellWithTitle:(id)arg1 detail:(id)arg2;
@end

@interface FRPViewCell /* superclass unresolved */
// 0xb4138 encoding: @36@0:8i16@?20@?28
- (id /* see encoding for actual type */)cellWithHeight:(id)arg1 initBlock:(id)arg2 layoutBlock:(id)arg3;
// 0xb423c encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xb42d8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)addSubview:(id)arg1;
// 0xb43b0 encoding: @?16@0:8
- (id /* see encoding for actual type */)layoutBlock;
// 0xb43c0 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)setLayoutBlock:(id)arg1;
// 0xb43cc encoding: B16@0:8
- (id /* see encoding for actual type */)hideSeperators;
// 0xb43dc encoding: v20@0:8B16
- (id /* see encoding for actual type */)setHideSeperators:(id)arg1;
// 0xb43ec encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xb40a8 encoding: @36@0:8i16@?20@?28
+ (id /* see encoding for actual type */)cellWithHeight:(id)arg1 initBlock:(id)arg2 layoutBlock:(id)arg3;
@end

@interface FRPViewSection /* superclass unresolved */
// 0xb447c encoding: @36@0:8i16@?20@?28
- (id /* see encoding for actual type */)initWithHeight:(id)arg1 initBlock:(id)arg2 layoutBlock:(id)arg3;
// 0xb4628 encoding: @?16@0:8
- (id /* see encoding for actual type */)cellBlock;
// 0xb4638 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)setCellBlock:(id)arg1;
// 0xb4644 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xb4400 encoding: @36@0:8i16@?20@?28
+ (id /* see encoding for actual type */)sectionWithHeight:(id)arg1 initBlock:(id)arg2 layoutBlock:(id)arg3;
@end

@interface FRPreferences /* superclass unresolved */
// 0xb4708 encoding: @24@0:8@16
- (id /* see encoding for actual type */)initTableWithSections:(id)arg1;
// 0xb4780 encoding: v16@0:8
- (id /* see encoding for actual type */)updateTintColors;
// 0xb4ad4 encoding: v20@0:8B16
- (id /* see encoding for actual type */)viewDidDisappear:(id)arg1;
// 0xb4b08 encoding: v20@0:8B16
- (id /* see encoding for actual type */)viewWillAppear:(id)arg1;
// 0xb5138 encoding: @24@0:8@16
- (id /* see encoding for actual type */)cellForIndexPath:(id)arg1;
// 0xb5230 encoding: q24@0:8@16
- (id /* see encoding for actual type */)numberOfSectionsInTableView:(id)arg1;
// 0xb527c encoding: @32@0:8@16q24
- (id /* see encoding for actual type */)tableView:(id)arg1 titleForHeaderInSection:(id)arg2;
// 0xb5300 encoding: q32@0:8@16q24
- (id /* see encoding for actual type */)tableView:(id)arg1 numberOfRowsInSection:(id)arg2;
// 0xb53a0 encoding: d32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 heightForRowAtIndexPath:(id)arg2;
// 0xb541c encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 cellForRowAtIndexPath:(id)arg2;
// 0xb552c encoding: v32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 didSelectRowAtIndexPath:(id)arg2;
// 0xb559c encoding: @32@0:8@16q24
- (id /* see encoding for actual type */)tableView:(id)arg1 titleForFooterInSection:(id)arg2;
// 0xb5620 encoding: v40@0:8@16@24q32
- (id /* see encoding for actual type */)tableView:(id)arg1 willDisplayHeaderView:(id)arg2 forSection:(id)arg3;
// 0xb5830 encoding: v40@0:8@16@24q32
- (id /* see encoding for actual type */)tableView:(id)arg1 willDisplayFooterView:(id)arg2 forSection:(id)arg3;
// 0xb5904 encoding: @32@0:8@16q24
- (id /* see encoding for actual type */)tableView:(id)arg1 viewForFooterInSection:(id)arg2;
// 0xb5b20 encoding: v16@0:8
- (id /* see encoding for actual type */)reloadTableView;
// 0xb5b60 encoding: @16@0:8
- (id /* see encoding for actual type */)sections;
// 0xb5b70 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setSections:(id)arg1;
// 0xb5b84 encoding: @16@0:8
- (id /* see encoding for actual type */)plistPath;
// 0xb5b94 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setPlistPath:(id)arg1;
// 0xb5ba8 encoding: @16@0:8
- (id /* see encoding for actual type */)tintUIColor;
// 0xb5bb8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTintUIColor:(id)arg1;
// 0xb5bcc encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
// 0xb4658 encoding: @40@0:8@16@24@32
+ (id /* see encoding for actual type */)tableWithSections:(id)arg1 title:(id)arg2 tintColor:(id)arg3;
@end

@interface DLSSProfileViewController /* superclass unresolved */
// 0xb5c20 encoding: @24@0:8@16
- (id /* see encoding for actual type */)initWithProfilePicURL:(id)arg1;
// 0xb5c94 encoding: @24@0:8@16
- (id /* see encoding for actual type */)initWithProfilePicByUserPK:(id)arg1;
// 0xb5d08 encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLoad;
// 0xb6730 encoding: v16@0:8
- (id /* see encoding for actual type */)prepareImageToDownload;
// 0xb6de0 encoding: v24@0:8@?16
- (id /* see encoding for actual type */)downloadImage:(id)arg1;
// 0xb70b4 encoding: v16@0:8
- (id /* see encoding for actual type */)dismissCV;
// 0xb70c8 encoding: v16@0:8
- (id /* see encoding for actual type */)shareNow;
// 0xb71f0 encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLayoutSubviews;
// 0xb71fc encoding: @24@0:8@16
- (id /* see encoding for actual type */)viewForZoomingInScrollView:(id)arg1;
// 0xb7208 encoding: v24@0:8@16
- (id /* see encoding for actual type */)scrollViewDidZoom:(id)arg1;
// 0xb7214 encoding: v16@0:8
- (id /* see encoding for actual type */)centerContentInScrollViewIfNeeded;
// 0xb7424 encoding: @16@0:8
- (id /* see encoding for actual type */)HDProfilePicURL;
// 0xb7434 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setHDProfilePicURL:(id)arg1;
// 0xb7448 encoding: @16@0:8
- (id /* see encoding for actual type */)userPK;
// 0xb7458 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setUserPK:(id)arg1;
// 0xb746c encoding: @16@0:8
- (id /* see encoding for actual type */)imageView;
// 0xb747c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setImageView:(id)arg1;
// 0xb7490 encoding: @16@0:8
- (id /* see encoding for actual type */)scrollView;
// 0xb74a0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setScrollView:(id)arg1;
// 0xb74b4 encoding: @16@0:8
- (id /* see encoding for actual type */)errorLabel;
// 0xb74c4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setErrorLabel:(id)arg1;
// 0xb74d8 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLCollectionViewFlowLayout /* superclass unresolved */
// 0xb7568 encoding: B16@0:8
- (id /* see encoding for actual type */)flipsHorizontallyInOppositeLayoutDirection;
@end

@interface DLMultiMediaOptionCell /* superclass unresolved */
// 0xb7570 encoding: @32@0:8q16@24
- (id /* see encoding for actual type */)initWithStyle:(id)arg1 reuseIdentifier:(id)arg2;
// 0xb7604 encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xb77ec encoding: v16@0:8
- (id /* see encoding for actual type */)setupViews;
// 0xb800c encoding: @16@0:8
- (id /* see encoding for actual type */)containerView;
// 0xb801c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setContainerView:(id)arg1;
// 0xb8030 encoding: @16@0:8
- (id /* see encoding for actual type */)titleLabel;
// 0xb8040 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTitleLabel:(id)arg1;
// 0xb8054 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLMultiMediaViewCell /* superclass unresolved */
// 0xb8094 encoding: @48@0:8{CGRect={CGPoint=dd}{CGSize=dd}}16
- (id /* see encoding for actual type */)initWithFrame:(id)arg1;
// 0xb813c encoding: v16@0:8
- (id /* see encoding for actual type */)layoutSubviews;
// 0xb82fc encoding: v16@0:8
- (id /* see encoding for actual type */)prepareForReuse;
// 0xb8370 encoding: v16@0:8
- (id /* see encoding for actual type */)setupContainerViewCell;
// 0xb86e8 encoding: v16@0:8
- (id /* see encoding for actual type */)setupIndicatorView;
// 0xb8960 encoding: v16@0:8
- (id /* see encoding for actual type */)setupMediaImageView;
// 0xb8c34 encoding: v16@0:8
- (id /* see encoding for actual type */)setupErrorLabel;
// 0xb8f68 encoding: v16@0:8
- (id /* see encoding for actual type */)setupDurationLabel;
// 0xb92a4 encoding: v16@0:8
- (id /* see encoding for actual type */)setupCheckmarkView;
// 0xb9824 encoding: @16@0:8
- (id /* see encoding for actual type */)containerViewCell;
// 0xb9834 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setContainerViewCell:(id)arg1;
// 0xb9848 encoding: @16@0:8
- (id /* see encoding for actual type */)indicatorView;
// 0xb9858 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setIndicatorView:(id)arg1;
// 0xb986c encoding: @16@0:8
- (id /* see encoding for actual type */)mediaImageView;
// 0xb987c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setMediaImageView:(id)arg1;
// 0xb9890 encoding: @16@0:8
- (id /* see encoding for actual type */)mediaImage;
// 0xb98a0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setMediaImage:(id)arg1;
// 0xb98b4 encoding: @16@0:8
- (id /* see encoding for actual type */)durationLabel;
// 0xb98c4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setDurationLabel:(id)arg1;
// 0xb98d8 encoding: @16@0:8
- (id /* see encoding for actual type */)checkmarkView;
// 0xb98e8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setCheckmarkView:(id)arg1;
// 0xb98fc encoding: @16@0:8
- (id /* see encoding for actual type */)checkmarkImageView;
// 0xb990c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setCheckmarkImageView:(id)arg1;
// 0xb9920 encoding: @16@0:8
- (id /* see encoding for actual type */)errorLabel;
// 0xb9930 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setErrorLabel:(id)arg1;
// 0xb9944 encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end

@interface DLMultiMediaViewController /* superclass unresolved */
// 0xb99fc encoding: v16@0:8
- (id /* see encoding for actual type */)viewDidLoad;
// 0xb9d6c encoding: v16@0:8
- (id /* see encoding for actual type */)setupMediaCollectionView;
// 0xbab0c encoding: v32@0:8{CGSize=dd}16
- (id /* see encoding for actual type */)updateCollectionViewForSize:(id)arg1;
// 0xbaba0 encoding: q32@0:8@16q24
- (id /* see encoding for actual type */)collectionView:(id)arg1 numberOfItemsInSection:(id)arg2;
// 0xbabec encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)collectionView:(id)arg1 cellForItemAtIndexPath:(id)arg2;
// 0xbb32c encoding: {CGSize=dd}40@0:8@16@24@32
- (id /* see encoding for actual type */)collectionView:(id)arg1 layout:(id)arg2 sizeForItemAtIndexPath:(id)arg3;
// 0xbb338 encoding: v32@0:8@16@24
- (id /* see encoding for actual type */)collectionView:(id)arg1 didSelectItemAtIndexPath:(id)arg2;
// 0xbb71c encoding: v16@0:8
- (id /* see encoding for actual type */)setupOptionTableView;
// 0xbbd68 encoding: q32@0:8@16q24
- (id /* see encoding for actual type */)tableView:(id)arg1 numberOfRowsInSection:(id)arg2;
// 0xbbd70 encoding: @32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 cellForRowAtIndexPath:(id)arg2;
// 0xbc054 encoding: v40@0:8@16@24@32
- (id /* see encoding for actual type */)tableView:(id)arg1 willDisplayCell:(id)arg2 forRowAtIndexPath:(id)arg3;
// 0xbc0f0 encoding: v32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 didSelectRowAtIndexPath:(id)arg2;
// 0xbc2b8 encoding: d32@0:8@16@24
- (id /* see encoding for actual type */)tableView:(id)arg1 heightForRowAtIndexPath:(id)arg2;
// 0xbc2c4 encoding: v16@0:8
- (id /* see encoding for actual type */)didPressSelectAllMedia;
// 0xbc5b0 encoding: v16@0:8
- (id /* see encoding for actual type */)didPressUnselectAllMedia;
// 0xbc7b8 encoding: v16@0:8
- (id /* see encoding for actual type */)didPressDownloadMedia;
// 0xbce7c encoding: @16@0:8
- (id /* see encoding for actual type */)posts;
// 0xbce8c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setPosts:(id)arg1;
// 0xbcea0 encoding: @16@0:8
- (id /* see encoding for actual type */)containerMediaCollectionView;
// 0xbceb0 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setContainerMediaCollectionView:(id)arg1;
// 0xbcec4 encoding: @16@0:8
- (id /* see encoding for actual type */)mediaCollectionView;
// 0xbced4 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setMediaCollectionView:(id)arg1;
// 0xbcee8 encoding: @16@0:8
- (id /* see encoding for actual type */)titleLabel;
// 0xbcef8 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setTitleLabel:(id)arg1;
// 0xbcf0c encoding: @16@0:8
- (id /* see encoding for actual type */)allSelectedMedia;
// 0xbcf1c encoding: v24@0:8@16
- (id /* see encoding for actual type */)setAllSelectedMedia:(id)arg1;
// 0xbcf30 encoding: {CGSize=dd}16@0:8
- (id /* see encoding for actual type */)collectionCellSize;
// 0xbcf44 encoding: v32@0:8{CGSize=dd}16
- (id /* see encoding for actual type */)setCollectionCellSize:(id)arg1;
// 0xbcf58 encoding: @16@0:8
- (id /* see encoding for actual type */)optionTableView;
// 0xbcf68 encoding: v24@0:8@16
- (id /* see encoding for actual type */)setOptionTableView:(id)arg1;
// 0xbcf7c encoding: v16@0:8
- (id /* see encoding for actual type */).cxx_destruct;
@end