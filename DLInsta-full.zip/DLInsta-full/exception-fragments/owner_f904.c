
/* FRAGMENT entry=0xfa4c owner=0xf904; not a source function; entry state unresolved */

/* WARNING: Function: _objc_release replaced with injection: _objc_release_fixup */

void UndefinedFunction_0000fa4c(_Unwind_Exception *param_1)

{
                    /* WARNING: Subroutine does not return */
  __Unwind_Resume(param_1);
}

