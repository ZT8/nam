/* Address: 00010c58 | Name: FUN_00010c58 | Body bytes: 72 */

void FUN_00010c58(long param_1)

{
  code *UNRECOVERED_JUMPTABLE;
  
  UNRECOVERED_JUMPTABLE = DAT_000ff8f0;
  if (DAT_000ff8f0 == (code *)0x0) {
    UNRECOVERED_JUMPTABLE =
         (code *)_class_getMethodImplementation(DAT_000ff8e8,"UFIButtonBarDidTapOnLike:");
  }
                    /* WARNING: Could not recover jumptable at 0x00010c9c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)
            (*(undefined8 *)(param_1 + 0x28),*(undefined8 *)(param_1 + 0x30),
             *(undefined8 *)(param_1 + 0x20));
  return;
}

